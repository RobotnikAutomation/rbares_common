
"use strict";

let set_digital_output = require('./set_digital_output.js')
let enable_disable = require('./enable_disable.js')
let InsertTask = require('./InsertTask.js')
let GetBool = require('./GetBool.js')
let axis_record = require('./axis_record.js')
let get_modbus_register = require('./get_modbus_register.js')
let set_named_digital_output = require('./set_named_digital_output.js')
let SetLaserMode = require('./SetLaserMode.js')
let SetMotorMode = require('./SetMotorMode.js')
let SetEncoderTurns = require('./SetEncoderTurns.js')
let set_float_value = require('./set_float_value.js')
let set_mode = require('./set_mode.js')
let set_odometry = require('./set_odometry.js')
let SetMotorPID = require('./SetMotorPID.js')
let set_modbus_register = require('./set_modbus_register.js')
let get_mode = require('./get_mode.js')
let SetMotorStatus = require('./SetMotorStatus.js')
let set_ptz = require('./set_ptz.js')
let QueryAlarms = require('./QueryAlarms.js')
let get_alarms = require('./get_alarms.js')
let SetByte = require('./SetByte.js')
let SetElevator = require('./SetElevator.js')
let SetTransform = require('./SetTransform.js')
let set_analog_output = require('./set_analog_output.js')
let SetNamedDigitalOutput = require('./SetNamedDigitalOutput.js')
let get_digital_input = require('./get_digital_input.js')
let set_height = require('./set_height.js')
let ResetFromSubState = require('./ResetFromSubState.js')
let ack_alarm = require('./ack_alarm.js')
let home = require('./home.js')
let GetMotorsHeadingOffset = require('./GetMotorsHeadingOffset.js')
let set_CartesianEuler_pose = require('./set_CartesianEuler_pose.js')
let SetBuzzer = require('./SetBuzzer.js')

module.exports = {
  set_digital_output: set_digital_output,
  enable_disable: enable_disable,
  InsertTask: InsertTask,
  GetBool: GetBool,
  axis_record: axis_record,
  get_modbus_register: get_modbus_register,
  set_named_digital_output: set_named_digital_output,
  SetLaserMode: SetLaserMode,
  SetMotorMode: SetMotorMode,
  SetEncoderTurns: SetEncoderTurns,
  set_float_value: set_float_value,
  set_mode: set_mode,
  set_odometry: set_odometry,
  SetMotorPID: SetMotorPID,
  set_modbus_register: set_modbus_register,
  get_mode: get_mode,
  SetMotorStatus: SetMotorStatus,
  set_ptz: set_ptz,
  QueryAlarms: QueryAlarms,
  get_alarms: get_alarms,
  SetByte: SetByte,
  SetElevator: SetElevator,
  SetTransform: SetTransform,
  set_analog_output: set_analog_output,
  SetNamedDigitalOutput: SetNamedDigitalOutput,
  get_digital_input: get_digital_input,
  set_height: set_height,
  ResetFromSubState: ResetFromSubState,
  ack_alarm: ack_alarm,
  home: home,
  GetMotorsHeadingOffset: GetMotorsHeadingOffset,
  set_CartesianEuler_pose: set_CartesianEuler_pose,
  SetBuzzer: SetBuzzer,
};
