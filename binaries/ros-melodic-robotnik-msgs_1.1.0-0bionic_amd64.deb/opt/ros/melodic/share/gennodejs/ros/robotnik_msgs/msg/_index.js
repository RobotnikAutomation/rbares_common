
"use strict";

let Registers = require('./Registers.js');
let Data = require('./Data.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let Interfaces = require('./Interfaces.js');
let inputs_outputs = require('./inputs_outputs.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let LaserMode = require('./LaserMode.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let ReturnMessage = require('./ReturnMessage.js');
let BatteryStatus = require('./BatteryStatus.js');
let MotorsStatus = require('./MotorsStatus.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let Register = require('./Register.js');
let ElevatorAction = require('./ElevatorAction.js');
let MotorStatus = require('./MotorStatus.js');
let Alarms = require('./Alarms.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let Pose2DArray = require('./Pose2DArray.js');
let StringArray = require('./StringArray.js');
let LaserStatus = require('./LaserStatus.js');
let encoders = require('./encoders.js');
let BoolArray = require('./BoolArray.js');
let InverterStatus = require('./InverterStatus.js');
let SubState = require('./SubState.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let ptz = require('./ptz.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let MotorPID = require('./MotorPID.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let State = require('./State.js');
let PresenceSensorArray = require('./PresenceSensorArray.js');
let QueryAlarm = require('./QueryAlarm.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let AlarmSensor = require('./AlarmSensor.js');
let PresenceSensor = require('./PresenceSensor.js');
let named_input_output = require('./named_input_output.js');
let alarmmonitor = require('./alarmmonitor.js');
let Axis = require('./Axis.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');

module.exports = {
  Registers: Registers,
  Data: Data,
  BatteryDockingStatus: BatteryDockingStatus,
  Interfaces: Interfaces,
  inputs_outputs: inputs_outputs,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  LaserMode: LaserMode,
  BatteryStatusStamped: BatteryStatusStamped,
  MotorHeadingOffset: MotorHeadingOffset,
  ReturnMessage: ReturnMessage,
  BatteryStatus: BatteryStatus,
  MotorsStatus: MotorsStatus,
  alarmsmonitor: alarmsmonitor,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  Register: Register,
  ElevatorAction: ElevatorAction,
  MotorStatus: MotorStatus,
  Alarms: Alarms,
  ElevatorStatus: ElevatorStatus,
  Pose2DArray: Pose2DArray,
  StringArray: StringArray,
  LaserStatus: LaserStatus,
  encoders: encoders,
  BoolArray: BoolArray,
  InverterStatus: InverterStatus,
  SubState: SubState,
  MotorsStatusDifferential: MotorsStatusDifferential,
  ptz: ptz,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  MotorPID: MotorPID,
  Pose2DStamped: Pose2DStamped,
  State: State,
  PresenceSensorArray: PresenceSensorArray,
  QueryAlarm: QueryAlarm,
  SafetyModuleStatus: SafetyModuleStatus,
  AlarmSensor: AlarmSensor,
  PresenceSensor: PresenceSensor,
  named_input_output: named_input_output,
  alarmmonitor: alarmmonitor,
  Axis: Axis,
  named_inputs_outputs: named_inputs_outputs,
  SetElevatorResult: SetElevatorResult,
  SetElevatorActionGoal: SetElevatorActionGoal,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorAction: SetElevatorAction,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorActionResult: SetElevatorActionResult,
};
