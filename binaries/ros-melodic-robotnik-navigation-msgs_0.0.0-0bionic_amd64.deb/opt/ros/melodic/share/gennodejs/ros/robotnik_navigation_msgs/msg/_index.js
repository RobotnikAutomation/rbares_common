
"use strict";

let PoseStampedArray = require('./PoseStampedArray.js');
let MoveFeedback = require('./MoveFeedback.js');
let MoveGoal = require('./MoveGoal.js');
let DockActionFeedback = require('./DockActionFeedback.js');
let DockAction = require('./DockAction.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let DockGoal = require('./DockGoal.js');
let MoveAction = require('./MoveAction.js');
let DockActionGoal = require('./DockActionGoal.js');
let DockActionResult = require('./DockActionResult.js');
let DockResult = require('./DockResult.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let DockFeedback = require('./DockFeedback.js');
let MoveActionResult = require('./MoveActionResult.js');
let MoveResult = require('./MoveResult.js');

module.exports = {
  PoseStampedArray: PoseStampedArray,
  MoveFeedback: MoveFeedback,
  MoveGoal: MoveGoal,
  DockActionFeedback: DockActionFeedback,
  DockAction: DockAction,
  MoveActionFeedback: MoveActionFeedback,
  DockGoal: DockGoal,
  MoveAction: MoveAction,
  DockActionGoal: DockActionGoal,
  DockActionResult: DockActionResult,
  DockResult: DockResult,
  MoveActionGoal: MoveActionGoal,
  DockFeedback: DockFeedback,
  MoveActionResult: MoveActionResult,
  MoveResult: MoveResult,
};
